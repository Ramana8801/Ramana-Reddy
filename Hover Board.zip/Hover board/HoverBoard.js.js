var container = document.getElementById('cursor')
var colors = ['red', 'blue', 'green', 'yellow', 'white']
var SQUARES = 400

for(let i = 0; i < SQUARES; i++) {
    const square = document.createElement('div')
    square.classList.add('square')    /*The classList property returns the class name(s) of an element,This property is useful to add, remove and toggle CSS classes on an element.*/
    container.appendChild(square)    /*Adds a new child node, to an element, as the last child node*/
    /*document.addEventListener(event, function, useCapture)*/
    square.addEventListener('mouseover', () => setColor(square))       /*Arrow functions were introduced in ES6.
*/
    square.addEventListener('mouseout', () => removeColor(square))
    
}

function setColor(element) {
   var color = getRandomColor()
   element.style.background = color
}

function removeColor(element) {
   element.style.background = 'black'
}
/*generates a random index for the colors array;*/
function getRandomColor() {
     return colors[Math.floor(Math.random() * colors.length)]  
}